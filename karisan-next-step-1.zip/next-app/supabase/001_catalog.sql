begin;

create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

create table if not exists private.catalog_admin (
  singleton boolean primary key default true check (singleton),
  user_id uuid not null unique references auth.users(id) on delete cascade
);
revoke all on private.catalog_admin from public, anon, authenticated;

create or replace function public.is_catalog_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from private.catalog_admin
    where user_id = auth.uid()
  );
$$;
revoke all on function public.is_catalog_admin() from public;
grant execute on function public.is_catalog_admin() to anon, authenticated;

create table if not exists public.catalog_products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) between 1 and 250),
  description text not null default '',
  price numeric(12,2) not null check (price >= 0),
  in_stock boolean not null default true,
  old_price numeric(12,2),
  sale_price numeric(12,2),
  sale_ends_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint catalog_sale_valid check (
    (old_price is null and sale_price is null and sale_ends_at is null)
    or
    (old_price is not null and sale_price is not null and sale_ends_at is not null
     and old_price > sale_price and sale_price >= 0)
  )
);

create table if not exists public.catalog_sizes (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.catalog_products(id) on delete cascade,
  name text not null check (length(trim(name)) between 1 and 100),
  in_stock boolean not null default true,
  sort_order integer not null default 0,
  unique (product_id, name)
);

create table if not exists public.catalog_photos (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.catalog_products(id) on delete cascade,
  storage_path text not null check (length(storage_path) > 0),
  alt text not null default '',
  sort_order integer not null default 0,
  unique (product_id, storage_path)
);

create index if not exists catalog_sizes_product_idx
on public.catalog_sizes(product_id);
create index if not exists catalog_photos_product_idx
on public.catalog_photos(product_id);

create or replace function public.touch_catalog_product()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
drop trigger if exists catalog_products_updated on public.catalog_products;
create trigger catalog_products_updated
before update on public.catalog_products
for each row execute function public.touch_catalog_product();

alter table public.catalog_products enable row level security;
alter table public.catalog_sizes enable row level security;
alter table public.catalog_photos enable row level security;

-- Both available and unavailable goods are visible in the public catalogue.
drop policy if exists catalog_products_read on public.catalog_products;
create policy catalog_products_read on public.catalog_products
for select to anon, authenticated using (true);
drop policy if exists catalog_sizes_read on public.catalog_sizes;
create policy catalog_sizes_read on public.catalog_sizes
for select to anon, authenticated using (true);
drop policy if exists catalog_photos_read on public.catalog_photos;
create policy catalog_photos_read on public.catalog_photos
for select to anon, authenticated using (true);

drop policy if exists catalog_products_admin on public.catalog_products;
create policy catalog_products_admin on public.catalog_products
for all to authenticated
using (public.is_catalog_admin()) with check (public.is_catalog_admin());
drop policy if exists catalog_sizes_admin on public.catalog_sizes;
create policy catalog_sizes_admin on public.catalog_sizes
for all to authenticated
using (public.is_catalog_admin()) with check (public.is_catalog_admin());
drop policy if exists catalog_photos_admin on public.catalog_photos;
create policy catalog_photos_admin on public.catalog_photos
for all to authenticated
using (public.is_catalog_admin()) with check (public.is_catalog_admin());

grant usage on schema public to anon, authenticated;
grant select on public.catalog_products, public.catalog_sizes, public.catalog_photos
  to anon;
grant select, insert, update, delete
  on public.catalog_products, public.catalog_sizes, public.catalog_photos
  to authenticated;

insert into storage.buckets
  (id, name, public, file_size_limit, allowed_mime_types)
values
  ('catalog-images', 'catalog-images', true, 5242880,
   array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists catalog_images_read on storage.objects;
create policy catalog_images_read on storage.objects
for select to anon, authenticated
using (bucket_id = 'catalog-images');
drop policy if exists catalog_images_admin on storage.objects;
create policy catalog_images_admin on storage.objects
for all to authenticated
using (bucket_id = 'catalog-images' and public.is_catalog_admin())
with check (bucket_id = 'catalog-images' and public.is_catalog_admin());

commit;
