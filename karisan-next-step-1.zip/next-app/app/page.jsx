import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <p className="text-sm tracking-widest text-purple-700">KARI-SAN</p>
      <h1 className="mt-4 text-3xl font-semibold">Каталог магазина</h1>
      <p className="mt-4 text-gray-600">
        Это отдельная версия на Next.js. Каталог добавим на следующем этапе.
      </p>
      <Link className="mt-8 inline-block underline" href="/admin/login">
        Вход администратора
      </Link>
    </main>
  );
}
