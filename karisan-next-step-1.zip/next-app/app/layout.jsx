import './globals.css';

export const metadata = {
  title: 'Kari-San',
  description: 'Каталог Kari-San',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
