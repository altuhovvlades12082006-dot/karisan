import { requireAdmin } from '../../../lib/auth';
import { logout } from '../login/actions';

export const dynamic = 'force-dynamic';
export const metadata = {
  title: 'Админка — Kari-San',
  robots: { index: false, follow: false },
};

export default async function AdminLayout({ children }) {
  const { user } = await requireAdmin();

  return (
    <div className="min-h-screen">
      <header className="border-b border-purple-100 bg-white px-5 py-5">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-4">
          <div>
            <p className="font-semibold">Kari-San — админка</p>
            <p className="mt-1 text-sm text-gray-600">{user.email}</p>
          </div>
          <form action={logout}>
            <button className="rounded-xl border border-purple-200 px-4 py-2">
              Выйти
            </button>
          </form>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-5 py-10">{children}</main>
    </div>
  );
}
