import { requireAdmin } from '../../../lib/auth';

export default async function AdminPage() {
  await requireAdmin();

  return (
    <section className="rounded-2xl border border-purple-100 bg-white p-6">
      <h1 className="text-2xl font-semibold">Вход выполнен</h1>
      <p className="mt-3 text-gray-600">
        Шаг 1: авторизация одного администратора и защита страниц готовы.
        Список товаров добавим на шаге 2.
      </p>
    </section>
  );
}
