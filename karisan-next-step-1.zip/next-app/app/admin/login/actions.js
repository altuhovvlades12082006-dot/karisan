'use server';

import { redirect } from 'next/navigation';
import { createClient } from '../../../lib/supabase/server';

export async function login(formData) {
  const email = String(formData.get('email') || '').trim();
  const password = String(formData.get('password') || '');
  const adminId = process.env.ADMIN_USER_ID;

  if (!adminId) {
    redirect('/admin/login?error=setup');
  }

  let destination = '/admin';

  try {
    const supabase = await createClient();
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error || !data.user) {
      destination = '/admin/login?error=credentials';
    } else if (data.user.id !== adminId) {
      await supabase.auth.signOut({ scope: 'local' });
      destination = '/admin/login?error=access';
    } else {
      const { data: allowed, error: permissionError } = await supabase.rpc(
        'is_catalog_admin'
      );

      if (permissionError || allowed !== true) {
        await supabase.auth.signOut({ scope: 'local' });
        destination = '/admin/login?error=access';
      }
    }
  } catch {
    destination = '/admin/login?error=connection';
  }

  redirect(destination);
}

export async function logout() {
  const supabase = await createClient();
  const { error } = await supabase.auth.signOut({ scope: 'local' });

  if (error) {
    throw new Error('Не удалось выйти. Повторите попытку.');
  }

  redirect('/admin/login');
}
