import { login } from './actions';

export const dynamic = 'force-dynamic';
export const metadata = {
  title: 'Вход — Kari-San',
  robots: { index: false, follow: false },
};

const errors = {
  setup: 'Укажите ADMIN_USER_ID в переменных окружения.',
  credentials: 'Не удалось войти. Проверьте email и пароль.',
  access: 'У этого аккаунта нет доступа к админке.',
  connection: 'Не удалось подключиться к Supabase. Проверьте настройки.',
};

export default async function LoginPage({ searchParams }) {
  const params = await searchParams;
  const configured = Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL &&
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY &&
    process.env.ADMIN_USER_ID
  );
  const message = configured ? errors[params.error] : errors.connection;

  return (
    <main className="flex min-h-screen items-center justify-center px-5 py-12">
      <section className="w-full max-w-md rounded-3xl border border-purple-100 bg-white p-8 shadow-xl">
        <p className="text-xs tracking-widest text-purple-700">KARI-SAN</p>
        <h1 className="mt-3 text-3xl font-semibold">Вход в админку</h1>
        <form action={login} className="mt-8 space-y-5">
          <label className="block text-sm">
            Email
            <input
              className="mt-2 w-full rounded-xl border border-gray-300 p-3"
              name="email"
              type="email"
              autoComplete="username"
              maxLength={254}
              required
            />
          </label>
          <label className="block text-sm">
            Пароль
            <input
              className="mt-2 w-full rounded-xl border border-gray-300 p-3"
              name="password"
              type="password"
              autoComplete="current-password"
              required
            />
          </label>
          {message && (
            <p role="alert" className="text-sm text-red-700">{message}</p>
          )}
          <button
            type="submit"
            disabled={!configured}
            className="w-full rounded-xl bg-purple-900 p-3 font-semibold text-white disabled:opacity-50"
          >
            Войти
          </button>
        </form>
      </section>
    </main>
  );
}
